# Reference Work

A portable Codex skill for developing creative work through inspected references. It connects observed source properties to concrete adaptations across writing, print, objects, spaces, sound, movement, images, and interactive work.

The Python helper searches a bundled catalog and local discoveries, records inspection evidence, and remembers adopted references across projects. It requires Python 3, uses no third-party packages, and requires no API key. Research and media inspection use the host's available tools.

## Install

From a downloaded copy of this repository, copy the folder containing `SKILL.md` into your skill directory as `reference-work`, usually `~/.codex/skills/reference-work`. Keep `scripts`, `references`, `agents`, and any bundled assets together. Then invoke `$reference-work` with your task in Codex.

The intended repository location is `https://github.com/dicnunz/reference-work`. Publication and installation are separate steps; this document does not claim that repository exists or that this copy is installed.

```sh
python3 scripts/reference.py --help
python3 scripts/reference.py search "repetition rhythm" --project my-project
```

See [the library guide](references/library.md) for import, inspection, selection, history, identity, and state controls. History defaults to `$XDG_STATE_HOME/reference-work` or `~/.local/state/reference-work`, outside the skill installation. Back up that directory to preserve your ledger. A stable project ID preserves continuity. Use a new ID for unrelated work.

[Development sources](references/development.md) describe adopted ideas. The helper's checks verify data and history mechanics. They do not measure taste or guarantee better artifacts.

## Rights

Original code and instructions are MIT licensed. Referenced works, images, recordings, and other third-party materials retain their own rights. Consult each record's rights evidence before reuse; the MIT license does not cover those assets. Metadata and preview provenance must remain attached to redistributed collection material.
