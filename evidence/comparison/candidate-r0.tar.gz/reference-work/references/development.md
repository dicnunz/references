# Development sources

The functional name **Reference Work** describes the practice this skill implements: find actual works, inspect them, and refer their useful properties to a new task. It avoids attaching a universal aesthetic or quality claim to a proper name.

Selected upstream skill material was read during development. The following ideas informed original instructions; no upstream code or prose is bundled as this project's original implementation.

- [Impeccable](https://github.com/pbakaus/impeccable), `source/skill/reference/new-work.md`: adopted respect for an established identity and derivation from concrete subject material. Its prescribed direction tournament and randomized concept machinery were not needed for this broader workflow.
- [Anthropic frontend-design](https://github.com/anthropics/skills/tree/main/skills/frontend-design): adopted subject-specific choices, actual-content construction, and critique of the artifact as built. Broader media require their own evidence, so UI styling prescriptions were not generalized.
- [Taste Skill](https://github.com/Leonxlnx/taste-skill), `skills/taste-skill/SKILL.md`: adopted attention to audience, supplied references, and preserved assets. Numeric aesthetic dials and look presets would narrow this skill's judgment and are not used.
- [Vercel web-design-guidelines](https://github.com/vercel-labs/agent-skills/tree/main/skills/web-design-guidelines): adopted compact routing to task-specific source material and concrete findings. Interface compliance is one kind of validation and does not stand in for creative quality.
- [Remotion skills](https://github.com/remotion-dev/skills), `skills/remotion-best-practices/SKILL.md`: adopted selective loading of medium-specific guidance. This package does not require Remotion or reproduce its framework rules.
- OpenAI's installed `skill-creator` guidance informed a lean entrypoint, progressive disclosure, portable metadata, and plumbing checks separated from behavioral evaluation.

These are design rationales, not benchmark results. Catalog inspection provenance accompanies records. Comparative artifact evaluation, if conducted, must be reported separately with the actual artifacts, conditions, failures, and disagreements.
